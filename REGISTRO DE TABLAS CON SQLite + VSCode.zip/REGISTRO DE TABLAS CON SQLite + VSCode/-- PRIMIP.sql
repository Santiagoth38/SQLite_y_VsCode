-- SQLite
SELECT * FROM Productos;
